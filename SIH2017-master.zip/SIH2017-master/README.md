# SIH2017
These are the code developed for Smart India Hackathon 2017

